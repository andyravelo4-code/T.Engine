#ifndef ENGINE_H
#define ENGINE_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ─── Constants ─── */
#define ENGINE_VERSION "0.1.0"

/* Keys */
#define KEY_A 0
#define KEY_B 1
#define KEY_C 2
#define KEY_D 3
#define KEY_E 4
#define KEY_F 5
#define KEY_G 6
#define KEY_H 7
#define KEY_I 8
#define KEY_J 9
#define KEY_K 10
#define KEY_L 11
#define KEY_M 12
#define KEY_N 13
#define KEY_O 14
#define KEY_P 15
#define KEY_Q 16
#define KEY_R 17
#define KEY_S 18
#define KEY_T 19
#define KEY_U 20
#define KEY_V 21
#define KEY_W 22
#define KEY_X 23
#define KEY_Y 24
#define KEY_Z 25
#define KEY_0 26
#define KEY_1 27
#define KEY_2 28
#define KEY_3 29
#define KEY_4 30
#define KEY_5 31
#define KEY_6 32
#define KEY_7 33
#define KEY_8 34
#define KEY_9 35
#define KEY_SPACE 36
#define KEY_ENTER 37
#define KEY_ESCAPE 38
#define KEY_BACKSPACE 39
#define KEY_TAB 40
#define KEY_UP 41
#define KEY_DOWN 42
#define KEY_LEFT 43
#define KEY_RIGHT 44
#define KEY_LSHIFT 45
#define KEY_RSHIFT 46
#define KEY_LCTRL 47
#define KEY_RCTRL 48
#define KEY_LALT 49
#define KEY_RALT 50

/* Mouse buttons */
#define MOUSE_LEFT 0
#define MOUSE_RIGHT 1
#define MOUSE_MIDDLE 2

/* ─── Color ─── */
typedef struct {
    uint8_t r, g, b, a;
} Color;

#define COLOR(r, g, b, a) ((Color){r, g, b, a})
#define RGB(r, g, b)      ((Color){r, g, b, 255})
#define BLACK             RGB(0, 0, 0)
#define WHITE             RGB(255, 255, 255)
#define RED               RGB(255, 0, 0)
#define GREEN             RGB(0, 255, 0)
#define BLUE              RGB(0, 0, 255)
#define YELLOW            RGB(255, 255, 0)
#define CYAN              RGB(0, 255, 255)
#define MAGENTA           RGB(255, 0, 255)
#define TRANSPARENT       ((Color){0, 0, 0, 0})

/* ─── Texture handle ─── */
typedef int Texture; /* >0 = valid texture, <=0 = none */

/* ─── Engine state ─── */
typedef struct Engine Engine;

/* ─── Callback types for engine_run ─── */
typedef void (*EngineUpdateFn)(Engine* e);
typedef void (*EngineDrawFn)(Engine* e);

/* ─── Public API ─── */

/* Init / shutdown */
Engine* engine_init(int width, int height, const char* title, bool fullscreen, bool pixel_art, bool vsync);
void    engine_close(Engine* e);
bool    engine_is_open(Engine* e);

/* Screen */
void engine_cls(Engine* e, Color c);
void engine_swap_buffers(Engine* e);
void engine_set_window_title(Engine* e, const char* title);
void engine_get_size(Engine* e, int* w, int* h);

/* Timing */
double engine_get_ticks(Engine* e);
double engine_get_delta(Engine* e);
void   engine_set_fps(Engine* e, int fps);
int    engine_get_fps(Engine* e);

/* Input (call once per frame) */
void engine_poll_events(Engine* e);
bool engine_key_down(Engine* e, int key);
bool engine_key_pressed(Engine* e, int key);
bool engine_key_released(Engine* e, int key);
bool engine_mouse_down(Engine* e, int btn);
bool engine_mouse_pressed(Engine* e, int btn);
bool engine_mouse_released(Engine* e, int btn);
void engine_mouse_pos(Engine* e, double* x, double* y);
void engine_mouse_delta(Engine* e, double* dx, double* dy);

/* Drawing – immediate mode (batched via VBO) */
void engine_rect(Engine* e, float x, float y, float w, float h, Color c);
void engine_rectb(Engine* e, float x, float y, float w, float h, Color c);
void engine_line(Engine* e, float x1, float y1, float x2, float y2, Color c);
void engine_circ(Engine* e, float cx, float cy, float r, Color c);
void engine_circb(Engine* e, float cx, float cy, float r, Color c);
void engine_tri(Engine* e, float x1, float y1, float x2, float y2, float x3, float y3, Color c);

/* Text */
void engine_text(Engine* e, const char* text, float x, float y, Color c, int font_size);
void engine_text_center(Engine* e, const char* text, float x, float y, Color c, int font_size);
float engine_text_width(Engine* e, const char* text, int font_size);

/* Textures / blit */
Texture engine_texture_load(Engine* e, const char* path);
void    engine_texture_free(Engine* e, Texture tex);
void    engine_blit(Engine* e, Texture tex, float dx, float dy, float dw, float dh,
                    float sx, float sy, float sw, float sh, Color tint);
void    engine_blit_full(Engine* e, Texture tex, float x, float y, Color tint);

/* Camera */
void engine_camera(Engine* e, float x, float y);

/* Audio */
bool engine_audio_init(Engine* e, int channels);
void engine_audio_close(Engine* e);
int  engine_sound_load(Engine* e, const char* path);
void engine_sound_play(Engine* e, int sound_id, int channel, float volume, float speed);
void engine_sound_stop_channel(Engine* e, int channel);
void engine_music_load(Engine* e, const char* path);
void engine_music_play(Engine* e, float volume);
void engine_music_stop(Engine* e);

/* Run-loop (like Python engine.run) — polls events, calls update(e) then draw(e), limits FPS, exits on ESC */
void engine_run(Engine* e, EngineUpdateFn update, EngineDrawFn draw);

/* Global pixel-art mode */
void engine_set_pixel_art(Engine* e, bool on);

#ifdef __cplusplus
}
#endif

#endif /* ENGINE_H */
