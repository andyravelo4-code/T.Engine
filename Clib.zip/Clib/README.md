# C Engine — Portage bas niveau du moteur pixel-art

Moteur de rendu 2D écrit en C (OpenGL 3.3 core), portage direct de l'API
Python `Tiavina.engine.gl`. Conçu pour les jeux pixel-art avec rendu
précis au pixel près.

## Avantages

| Critère | Python (`Tiavina.engine.gl`) | C (`Clib/`) |
|---------|------------------------------|-------------|
| Performance | Interprété, GIL | Compilé natif, pas d’overhead |
| Dépendances | Python 3 + PyOpenGL + GLFW + Pillow + miniaudio | Aucune — tout est embarqué (GLFW source + stb) |
| Déploiement | `pip install` + runtime Python | Un binaire statique, pas de runtime |
| Taille binaire | ~50 Mo (Python + libs) | ~550 Ko (statique, compressible) |
| Portabilité | Multi-OS (Python) | Linux Wayland (X11 possible) |

## Structure

```
Clib/
├── engine.h          # API publique (identique au Python)
├── engine.c          # Implémentation OpenGL 3.3 core (VBO + shaders)
├── main.c            # Démo primitives
├── test_blit.c       # Démo textures (blit)
├── Makefile          # Build auto (cmake + gcc)
├── GLFW/glfw3.h      # Header GLFW embarqué
└── deps/
    ├── glfw/         # Source GLFW 3.4 (build statique)
    ├── stb_truetype.h
    └── stb_image.h
```

## Build

```sh
cd Clib
make          # → demo + test_blit
make run      # lance la démo primitives
make run_blit # lance la démo textures
```

Le Makefile compile GLFW en statique une fois pour toutes. Les `.o` et
`.a` sont mis en cache ; seuls les fichiers modifiés sont recompilés.

## Utilisation

```c
#include "engine.h"

static void update(Engine *e) {
    /* logique jeu — appelée à chaque frame */
}

static void draw(Engine *e) {
    engine_cls(e, RGB(20, 20, 30));
    engine_rect(e, 100, 100, 40, 40, RED);
    engine_text(e, "Hello", 10, 10, WHITE, 6);
}

int main(void) {
    Engine *e = engine_init(640, 480, "Titre", 0, 1, 1);
    if (!e) return 1;
    engine_run(e, update, draw);
    engine_close(e);
    return 0;
}
```

## API

Toutes les fonctions prennent `Engine *e` en premier paramètre.

### Initialisation

```c
Engine *engine_init(int w, int h, const char *title,
                    bool fullscreen, bool pixel_art, bool vsync);
void    engine_close(Engine *e);
bool    engine_is_open(Engine *e);
void    engine_run(Engine *e, EngineUpdateFn update, EngineDrawFn draw);
```

`engine_run` boucle à 60 FPS : poll events → update → draw → swap buffers.
ESC quitte la boucle.

### Dessin

```c
engine_cls(e, color);
engine_rect(e, x, y, w, h, color);     // plein
engine_rectb(e, x, y, w, h, color);    // contour
engine_line(e, x1, y1, x2, y2, color);
engine_circ(e, cx, cy, r, color);      // plein
engine_circb(e, cx, cy, r, color);     // contour
engine_tri(e, x1,y1, x2,y2, x3,y3, color);
```

Tous les dessins passent par des VBO (pas de `glBegin/glEnd`).
Le flush est automatique dans `engine_swap_buffers`.

### Texte

```c
engine_text(e, "texte", x, y, color, font_size);
engine_text_center(e, "...", x, y, color, font_size);
float w = engine_text_width(e, "texte", font_size);
```

Police PressStart2P (6px par défaut), rendue via stb_truetype dans un
font atlas texture (ASCII 32-126). Le fichier `.ttf` est cherché dans
`./Engine/fonts/` ou `./PressStart2P.ttf`.

### Textures

```c
Texture t = engine_texture_load(e, "chemin.png");
engine_blit_full(e, t, x, y, WHITE);
engine_blit(e, t, dx, dy, dw, dh, sx, sy, sw, sh, tint);
engine_texture_free(e, t);
```

Chargement PNG via stb_image (RGBA). Filtre `GL_NEAREST` (pixel-art).
Le paramètre `tint` (Color) permet de teinter le sprite.

### Entrées

```c
engine_key_pressed(e, KEY_SPACE)   // pressé cette frame
engine_key_down(e, KEY_LEFT)       // maintenu
engine_key_released(e, KEY_ENTER)  // relâché cette frame
engine_mouse_pos(e, &x, &y);
engine_mouse_pressed(e, MOUSE_LEFT);
```

Constantes : `KEY_A`…`KEY_Z`, `KEY_0`…`KEY_9`, `KEY_UP`, `KEY_DOWN`,
`KEY_ESCAPE`, `KEY_SPACE`, etc.

### Caméra

```c
engine_camera(e, x, y);  // décale le monde
```

En mode `pixel_art=true` (défaut), les coordonnées caméra sont
arrondies à l'entier pour éviter le flou sub-pixel.

### Audio

L'audio est stubé (retourne `false` / ne fait rien). Une intégration
miniaudio est prévue.

## Différences avec la version Python

- **Plus rapide** : rendu natif, pas de GIL, VBO batching
- **Autonome** : pas de Python, pas de pip, un seul binaire
- **Même API** : les noms de fonctions et l'ordre des paramètres
  sont calqués sur `from Engine import engine as e`
- **Callback `engine_run`** : remplace la boucle `while` manuelle,
  identique à `e.run(update, draw)` en Python
- **Audio non implémenté** (en Python via miniaudio)
