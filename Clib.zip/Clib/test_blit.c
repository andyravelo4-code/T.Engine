#include <stdio.h>
#include <math.h>
#include "engine.h"

static Texture tex_feuille, tex_stuff, tex_tiles;
static float t = 0;

static void update(Engine *e) {
    t += (float)engine_get_delta(e);
}

static void draw(Engine *e) {
    engine_cls(e, RGB(30, 30, 40));

    /* Centre screen */
    float cx = 320, cy = 240;

    /* feuille1.png – full blit, rotating */
    float angle = t;
    float sx = cx + cosf(angle) * 80 - 32;
    float sy = cy + sinf(angle) * 80 - 32;
    engine_blit_full(e, tex_feuille, sx, sy, WHITE);

    /* stuff.png – full blit, static */
    engine_blit_full(e, tex_stuff, cx - 64, 300, WHITE);

    /* tiles_1.png (80×48) – sub‑rect blit 
       tile grid: 16×16 tiles in a 80×48 → 5 cols × 3 rows */
    int tile_w = 16, tile_h = 16;
    int cols = 5;
    float base_x = 60, base_y = 60;
    for (int row = 0; row < 3; row++) {
        for (int col = 0; col < cols; col++) {
            int idx = (int)(t * 4 + row * cols + col) % 15;
            int tx = (idx % cols) * tile_w;
            int ty = (idx / cols) * tile_h;
            engine_blit(e, tex_tiles,
                        base_x + col * 20, base_y + row * 20, 18, 18,
                        (float)tx, (float)ty, (float)tile_w, (float)tile_h,
                        WHITE);
        }
    }

    /* info text */
    engine_text(e, "Blit test: feuille + stuff + tiles", 10, 10, CYAN, 6);
    char fps[32];
    snprintf(fps, sizeof(fps), "%.0f FPS", 1.0 / engine_get_delta(e));
    engine_text(e, fps, 580, 10, WHITE, 6);
}

int main(void) {
    Engine *e = engine_init(640, 480, "Blit Test — C Engine", 0, 1, 1);
    if (!e) return 1;

    tex_feuille = engine_texture_load(e, "../assests/images/feuille1.png");
    tex_stuff   = engine_texture_load(e, "../assests/images/stuff.png");
    tex_tiles   = engine_texture_load(e, "../assests/images/tiles_1.png");

    if (!tex_feuille || !tex_stuff || !tex_tiles) {
        fprintf(stderr, "Failed to load textures\n");
        engine_close(e);
        return 1;
    }

    engine_run(e, update, draw);
    engine_texture_free(e, tex_feuille);
    engine_texture_free(e, tex_stuff);
    engine_texture_free(e, tex_tiles);
    engine_close(e);
    return 0;
}
