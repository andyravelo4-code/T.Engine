#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>

#include "engine.h"

#define GLFW_INCLUDE_NONE
#include "GLFW/glfw3.h"

/* ─── OpenGL function pointer typedefs ─── */
typedef unsigned int GLuint;
typedef int GLint;
typedef unsigned int GLenum;
typedef unsigned char GLubyte;
typedef float GLfloat;
typedef size_t GLsizeiptr;
typedef int GLsizei;
typedef char GLchar;
typedef void (*GLDEBUGPROC)(GLenum, GLenum, GLuint, GLenum, GLsizei, const GLchar*, const void*);

/* We define our own GL constants to avoid system header dependency */
#define GL_FALSE 0
#define GL_TRUE 1
#define GL_ZERO 0
#define GL_ONE 1
#define GL_SRC_ALPHA 0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_BLEND 0x0BE2
#define GL_ARRAY_BUFFER 0x8892
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#define GL_STATIC_DRAW 0x88E4
#define GL_DYNAMIC_DRAW 0x88E8
#define GL_FLOAT 0x1406
#define GL_UNSIGNED_BYTE 0x1401
#define GL_TRIANGLES 0x0004
#define GL_TRIANGLE_FAN 0x0006
#define GL_LINES 0x0001
#define GL_TEXTURE_2D 0x0DE1
#define GL_RGBA 0x1908
#define GL_RED 0x1903
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_NEAREST 0x2600
#define GL_LINEAR 0x2601
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
#define GL_CLAMP_TO_EDGE 0x812F
#define GL_COLOR_BUFFER_BIT 0x00004000
#define GL_VERTEX_SHADER 0x8B31
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#define GL_INFO_LOG_LENGTH 0x8B84
#define GL_TEXTURE0 0x84C0
#define GL_CURRENT_PROGRAM 0x8B8D
#define GL_FRONT 0x0404
#define GL_BACK 0x0405

/* ─── OpenGL function pointers ─── */
static void (*glClear)(GLenum) = NULL;
static void (*glClearColor)(GLfloat, GLfloat, GLfloat, GLfloat) = NULL;
static void (*glEnable)(GLenum) = NULL;
static void (*glBlendFunc)(GLenum, GLenum) = NULL;
static void (*glViewport)(GLint, GLint, GLsizeiptr, GLsizeiptr) = NULL;
static void (*glGenVertexArrays)(GLsizeiptr, GLuint*) = NULL;
static void (*glBindVertexArray)(GLuint) = NULL;
static void (*glDeleteVertexArrays)(GLsizeiptr, const GLuint*) = NULL;
static void (*glGenBuffers)(GLsizeiptr, GLuint*) = NULL;
static void (*glBindBuffer)(GLenum, GLuint) = NULL;
static void (*glBufferData)(GLenum, GLsizeiptr, const void*, GLenum) = NULL;
static void (*glDeleteBuffers)(GLsizeiptr, const GLuint*) = NULL;
static void (*glEnableVertexAttribArray)(GLuint) = NULL;
static void (*glDisableVertexAttribArray)(GLuint) = NULL;
static void (*glVertexAttribPointer)(GLuint, GLint, GLenum, GLubyte, GLsizeiptr, const void*) = NULL;
static GLuint (*glCreateShader)(GLenum) = NULL;
static void (*glShaderSource)(GLuint, GLsizeiptr, const GLchar* const*, const GLint*) = NULL;
static void (*glCompileShader)(GLuint) = NULL;
static void (*glGetShaderiv)(GLuint, GLenum, GLint*) = NULL;
static void (*glGetShaderInfoLog)(GLuint, GLsizeiptr, GLsizeiptr*, GLchar*) = NULL;
static void (*glDeleteShader)(GLuint) = NULL;
static GLuint (*glCreateProgram)(void) = NULL;
static void (*glAttachShader)(GLuint, GLuint) = NULL;
static void (*glLinkProgram)(GLuint) = NULL;
static void (*glGetProgramiv)(GLuint, GLenum, GLint*) = NULL;
static void (*glGetProgramInfoLog)(GLuint, GLsizeiptr, GLsizeiptr*, GLchar*) = NULL;
static void (*glUseProgram)(GLuint) = NULL;
static void (*glDeleteProgram)(GLuint) = NULL;
static GLint (*glGetUniformLocation)(GLuint, const GLchar*) = NULL;
static void (*glUniform1i)(GLint, GLint) = NULL;
static void (*glUniform4f)(GLint, GLfloat, GLfloat, GLfloat, GLfloat) = NULL;
static void (*glActiveTexture)(GLenum) = NULL;
static void (*glDrawArrays)(GLenum, GLint, GLsizeiptr) = NULL;
static void (*glGenTextures)(GLsizeiptr, GLuint*) = NULL;
static void (*glBindTexture)(GLenum, GLuint) = NULL;
static void (*glTexParameteri)(GLenum, GLenum, GLint) = NULL;
static void (*glTexImage2D)(GLenum, GLint, GLint, GLsizeiptr, GLsizeiptr, GLint, GLenum, GLenum, const void*) = NULL;
static void (*glDeleteTextures)(GLsizeiptr, const GLuint*) = NULL;
static void (*glPixelStorei)(GLenum, GLint) = NULL;

#define GL_LOAD(name) do { \
    *(void**)(&name) = glfwGetProcAddress(#name); \
    if (!name) { fprintf(stderr, "Engine: failed to load GL function: %s\n", #name); return -1; } \
} while(0)

static int load_gl_funcs(void) {
    GL_LOAD(glClear);
    GL_LOAD(glClearColor);
    GL_LOAD(glEnable);
    GL_LOAD(glBlendFunc);
    GL_LOAD(glViewport);
    GL_LOAD(glGenVertexArrays);
    GL_LOAD(glBindVertexArray);
    GL_LOAD(glDeleteVertexArrays);
    GL_LOAD(glGenBuffers);
    GL_LOAD(glBindBuffer);
    GL_LOAD(glBufferData);
    GL_LOAD(glDeleteBuffers);
    GL_LOAD(glEnableVertexAttribArray);
    GL_LOAD(glDisableVertexAttribArray);
    GL_LOAD(glVertexAttribPointer);
    GL_LOAD(glCreateShader);
    GL_LOAD(glShaderSource);
    GL_LOAD(glCompileShader);
    GL_LOAD(glGetShaderiv);
    GL_LOAD(glGetShaderInfoLog);
    GL_LOAD(glDeleteShader);
    GL_LOAD(glCreateProgram);
    GL_LOAD(glAttachShader);
    GL_LOAD(glLinkProgram);
    GL_LOAD(glGetProgramiv);
    GL_LOAD(glGetProgramInfoLog);
    GL_LOAD(glUseProgram);
    GL_LOAD(glDeleteProgram);
    GL_LOAD(glGetUniformLocation);
    GL_LOAD(glUniform1i);
    GL_LOAD(glUniform4f);
    GL_LOAD(glActiveTexture);
    GL_LOAD(glDrawArrays);
    GL_LOAD(glGenTextures);
    GL_LOAD(glBindTexture);
    GL_LOAD(glTexParameteri);
    GL_LOAD(glTexImage2D);
    GL_LOAD(glDeleteTextures);
    GL_LOAD(glPixelStorei);
    return 0;
}

/* ─── stb single-file libs (included after GL prototypes) ─── */
#define STB_TRUETYPE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "deps/stb_truetype.h"
#include "deps/stb_image.h"

/* ─── Internal helpers ─── */
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define CLAMP(x,lo,hi) MIN(MAX(x,lo),hi)
#define PI 3.14159265358979323846f

/* ─── Shaders ─── */
static const char* COLOR_VS =
    "#version 330 core\n"
    "layout(location=0) in vec2 pos;\n"
    "layout(location=1) in vec4 col;\n"
    "uniform vec4 view;\n"
    "out vec4 vCol;\n"
    "void main() {\n"
    "  vec2 s = pos - view.xy;\n"
    "  gl_Position = vec4(2.0*s.x/view.z - 1.0, 1.0 - 2.0*s.y/view.w, 0.0, 1.0);\n"
    "  vCol = col;\n"
    "}\n";

static const char* COLOR_FS =
    "#version 330 core\n"
    "in vec4 vCol;\n"
    "out vec4 fragColor;\n"
    "void main() { fragColor = vCol; }\n";

static const char* TEX_VS =
    "#version 330 core\n"
    "layout(location=0) in vec2 pos;\n"
    "layout(location=1) in vec2 uv;\n"
    "uniform vec4 view;\n"
    "out vec2 vUv;\n"
    "void main() {\n"
    "  vec2 s = pos - view.xy;\n"
    "  gl_Position = vec4(2.0*s.x/view.z - 1.0, 1.0 - 2.0*s.y/view.w, 0.0, 1.0);\n"
    "  vUv = uv;\n"
    "}\n";

static const char* TEX_FS =
    "#version 330 core\n"
    "in vec2 vUv;\n"
    "uniform sampler2D tex;\n"
    "uniform vec4 tint;\n"
    "out vec4 fragColor;\n"
    "void main() { fragColor = texture(tex, vUv) * tint; }\n";

/* ─── Internal types ─── */
typedef struct {
    GLuint vao, vbo;
    float *data;
    int cap, count;
    GLuint shader;
    GLint view_loc;
} ColorBatch;

typedef struct {
    GLuint vao, vbo;
    float *data;
    int cap, count;
    GLuint shader;
    GLint view_loc, tex_loc, tint_loc;
    GLuint active_tex;
} TexBatch;

typedef struct {
    GLuint tex_id;
    int w, h;
} TexInfo;

typedef struct {
    GLuint tex_id;
    int tex_w, tex_h;
    int cell_w, cell_h;
    int cols, rows;
    int *advance, *xoff, *yoff, *glyph_w, *glyph_h;
} FontAtlas;

struct Engine {
    GLFWwindow *win;
    int w, h;
    bool open, pixel_art;
    double last_time, delta;
    int target_fps;
    float cam_x, cam_y;

    /* Input */
    bool keys[512], prev_keys[512];
    bool mouse_buttons[16], prev_mouse[16];
    double mouse_x, mouse_y, prev_mouse_x, prev_mouse_y;

    /* GL */
    ColorBatch fill_batch, line_batch;
    TexBatch tex_batch;
    TexInfo *textures;
    int tex_cap, tex_count;
    FontAtlas font;
    bool font_ready;
    int font_pt;
};

/* ─── Shader compilation ─── */
static GLuint compile_shader(const char *vs_src, const char *fs_src) {
    GLuint vs, fs, prog;
    GLint ok;
    char log[512];

    vs = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vs, 1, &vs_src, NULL);
    glCompileShader(vs);
    glGetShaderiv(vs, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        glGetShaderInfoLog(vs, 512, NULL, log);
        fprintf(stderr, "Engine: vertex shader: %s\n", log);
        return 0;
    }

    fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &fs_src, NULL);
    glCompileShader(fs);
    glGetShaderiv(fs, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        glGetShaderInfoLog(fs, 512, NULL, log);
        fprintf(stderr, "Engine: fragment shader: %s\n", log);
        return 0;
    }

    prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        glGetProgramInfoLog(prog, 512, NULL, log);
        fprintf(stderr, "Engine: program link: %s\n", log);
        return 0;
    }
    glDeleteShader(vs);
    glDeleteShader(fs);
    return prog;
}

/* ─── Color batch ─── */
static void color_batch_init(ColorBatch *b, const char *vs, const char *fs) {
    b->shader = compile_shader(vs, fs);
    glGenVertexArrays(1, &b->vao);
    glGenBuffers(1, &b->vbo);
    b->cap = 4096;
    b->data = (float*)malloc(b->cap * 6 * sizeof(float));
    b->count = 0;
    b->view_loc = glGetUniformLocation(b->shader, "view");

    glBindVertexArray(b->vao);
    glBindBuffer(GL_ARRAY_BUFFER, b->vbo);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)(uintptr_t)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)(uintptr_t)(2*sizeof(float)));
    glBindVertexArray(0);
}

static void color_batch_add(ColorBatch *b, float x, float y, float r, float g, float bb, float a) {
    if (b->count >= b->cap) {
        b->cap *= 2;
        b->data = (float*)realloc(b->data, b->cap * 6 * sizeof(float));
    }
    int i = b->count * 6;
    b->data[i] = x; b->data[i+1] = y;
    b->data[i+2] = r; b->data[i+3] = g;
    b->data[i+4] = bb; b->data[i+5] = a;
    b->count++;
}

static void color_batch_flush(ColorBatch *b, Engine *e) {
    if (!b->count) return;
    glUseProgram(b->shader);
    glUniform4f(b->view_loc, e->cam_x, e->cam_y, (float)e->w, (float)e->h);
    glBindVertexArray(b->vao);
    glBindBuffer(GL_ARRAY_BUFFER, b->vbo);
    glBufferData(GL_ARRAY_BUFFER, b->count * 6 * sizeof(float), b->data, GL_DYNAMIC_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, b->count);
    glBindVertexArray(0);
    b->count = 0;
}

/* ─── Tex batch ─── */
static void tex_batch_init(TexBatch *b, const char *vs, const char *fs) {
    b->shader = compile_shader(vs, fs);
    glGenVertexArrays(1, &b->vao);
    glGenBuffers(1, &b->vbo);
    b->cap = 4096;
    b->data = (float*)malloc(b->cap * 4 * sizeof(float));
    b->count = 0;
    b->active_tex = 0;
    b->view_loc = glGetUniformLocation(b->shader, "view");
    b->tex_loc = glGetUniformLocation(b->shader, "tex");
    b->tint_loc = glGetUniformLocation(b->shader, "tint");

    glBindVertexArray(b->vao);
    glBindBuffer(GL_ARRAY_BUFFER, b->vbo);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)(uintptr_t)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)(uintptr_t)(2*sizeof(float)));
    glBindVertexArray(0);
}

static void tex_batch_add(TexBatch *b, float x, float y, float u, float v) {
    if (b->count >= b->cap) {
        b->cap *= 2;
        b->data = (float*)realloc(b->data, b->cap * 4 * sizeof(float));
    }
    int i = b->count * 4;
    b->data[i] = x; b->data[i+1] = y;
    b->data[i+2] = u; b->data[i+3] = v;
    b->count++;
}

static void tex_batch_flush(TexBatch *b, Engine *e) {
    if (!b->count) return;
    glUseProgram(b->shader);
    glUniform4f(b->view_loc, e->cam_x, e->cam_y, (float)e->w, (float)e->h);
    glUniform1i(b->tex_loc, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, b->active_tex);
    glBindVertexArray(b->vao);
    glBindBuffer(GL_ARRAY_BUFFER, b->vbo);
    glBufferData(GL_ARRAY_BUFFER, b->count * 4 * sizeof(float), b->data, GL_DYNAMIC_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, b->count);
    glBindVertexArray(0);
    b->count = 0;
    b->active_tex = 0;
}

/* ─── Font atlas ─── */
static int font_atlas_init(FontAtlas *fa, const unsigned char *ttf_data, int pt) {
    stbtt_fontinfo info;
    if (!stbtt_InitFont(&info, ttf_data, 0)) return -1;

    float scale = stbtt_ScaleForPixelHeight(&info, (float)pt);
    int first_char = 32, last_char = 126, num = last_char - first_char + 1;

    fa->advance = (int*)calloc(num, sizeof(int));
    fa->xoff = (int*)calloc(num, sizeof(int));
    fa->yoff = (int*)calloc(num, sizeof(int));
    fa->glyph_w = (int*)calloc(num, sizeof(int));
    fa->glyph_h = (int*)calloc(num, sizeof(int));
    fa->cell_w = 0; fa->cell_h = 0;

    for (int i = 0; i < num; i++) {
        int c = i + first_char;
        int ax, lsb;
        stbtt_GetCodepointHMetrics(&info, c, &ax, &lsb);
        fa->advance[i] = (int)(ax * scale);
        int cw, ch, xo, yo;
        unsigned char *bm = stbtt_GetCodepointBitmap(&info, scale, scale, c, &cw, &ch, &xo, &yo);
        fa->xoff[i] = xo; fa->yoff[i] = yo;
        fa->glyph_w[i] = cw; fa->glyph_h[i] = ch;
        if (cw > fa->cell_w) fa->cell_w = cw;
        if (ch > fa->cell_h) fa->cell_h = ch;
        if (bm) stbtt_FreeBitmap(bm, NULL);
    }

    fa->cols = (int)ceil(sqrt((double)num));
    fa->rows = (num + fa->cols - 1) / fa->cols;
    fa->tex_w = fa->cols * (fa->cell_w + 2);
    fa->tex_h = fa->rows * (fa->cell_h + 2);
    if (fa->tex_w < 1) fa->tex_w = 1;
    if (fa->tex_h < 1) fa->tex_h = 1;

    unsigned char *atlas = (unsigned char*)calloc(fa->tex_w * fa->tex_h, 1);
    for (int i = 0; i < num; i++) {
        int c = i + first_char;
        int cw = fa->glyph_w[i], ch = fa->glyph_h[i];
        if (cw <= 0 || ch <= 0) continue;
        unsigned char *bm = stbtt_GetCodepointBitmap(&info, scale, scale, c, &cw, &ch,
                                                     &fa->xoff[i], &fa->yoff[i]);
        if (!bm) continue;
        int col = i % fa->cols, row = i / fa->cols;
        int dst_x = col * (fa->cell_w + 2) + 1;
        int dst_y = row * (fa->cell_h + 2) + 1;
        for (int y = 0; y < ch && y < fa->cell_h; y++)
            for (int x = 0; x < cw && x < fa->cell_w; x++)
                atlas[(dst_y + y) * fa->tex_w + (dst_x + x)] = bm[y * cw + x];
        stbtt_FreeBitmap(bm, NULL);
    }

    glGenTextures(1, &fa->tex_id);
    glBindTexture(GL_TEXTURE_2D, fa->tex_id);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RED, fa->tex_w, fa->tex_h, 0, GL_RED, GL_UNSIGNED_BYTE, atlas);
    free(atlas);
    fa->cell_w += 2;
    fa->cell_h += 2;
    return 0;
}

/* ─── Key mapping ─── */
static int glfw_to_engine_key(int k) {
    switch (k) {
        case GLFW_KEY_A: return 0; case GLFW_KEY_B: return 1;
        case GLFW_KEY_C: return 2; case GLFW_KEY_D: return 3;
        case GLFW_KEY_E: return 4; case GLFW_KEY_F: return 5;
        case GLFW_KEY_G: return 6; case GLFW_KEY_H: return 7;
        case GLFW_KEY_I: return 8; case GLFW_KEY_J: return 9;
        case GLFW_KEY_K: return 10; case GLFW_KEY_L: return 11;
        case GLFW_KEY_M: return 12; case GLFW_KEY_N: return 13;
        case GLFW_KEY_O: return 14; case GLFW_KEY_P: return 15;
        case GLFW_KEY_Q: return 16; case GLFW_KEY_R: return 17;
        case GLFW_KEY_S: return 18; case GLFW_KEY_T: return 19;
        case GLFW_KEY_U: return 20; case GLFW_KEY_V: return 21;
        case GLFW_KEY_W: return 22; case GLFW_KEY_X: return 23;
        case GLFW_KEY_Y: return 24; case GLFW_KEY_Z: return 25;
        case GLFW_KEY_0: return 26; case GLFW_KEY_1: return 27;
        case GLFW_KEY_2: return 28; case GLFW_KEY_3: return 29;
        case GLFW_KEY_4: return 30; case GLFW_KEY_5: return 31;
        case GLFW_KEY_6: return 32; case GLFW_KEY_7: return 33;
        case GLFW_KEY_8: return 34; case GLFW_KEY_9: return 35;
        case GLFW_KEY_SPACE: return 36; case GLFW_KEY_ENTER: return 37;
        case GLFW_KEY_ESCAPE: return 38; case GLFW_KEY_BACKSPACE: return 39;
        case GLFW_KEY_TAB: return 40; case GLFW_KEY_UP: return 41;
        case GLFW_KEY_DOWN: return 42; case GLFW_KEY_LEFT: return 43;
        case GLFW_KEY_RIGHT: return 44; case GLFW_KEY_LEFT_SHIFT: return 45;
        case GLFW_KEY_RIGHT_SHIFT: return 46; case GLFW_KEY_LEFT_CONTROL: return 47;
        case GLFW_KEY_RIGHT_CONTROL: return 48; case GLFW_KEY_LEFT_ALT: return 49;
        case GLFW_KEY_RIGHT_ALT: return 50;
        default: return -1;
    }
}

/* ─── GLFW callbacks ─── */
static void key_cb(GLFWwindow* w, int key, int sc, int act, int mods) {
    Engine *e = (Engine*)glfwGetWindowUserPointer(w);
    if (!e) return;
    int ek = glfw_to_engine_key(key);
    if (ek >= 0 && ek < 512) e->keys[ek] = (act == GLFW_PRESS || act == GLFW_REPEAT);
}

static void mouse_cb(GLFWwindow* w, int btn, int act, int mods) {
    Engine *e = (Engine*)glfwGetWindowUserPointer(w);
    if (!e) return;
    if (btn >= 0 && btn < 16) e->mouse_buttons[btn] = (act == GLFW_PRESS);
}

/* ─── Public API ─── */
Engine* engine_init(int width, int height, const char* title, bool fullscreen, bool pixel_art, bool vsync) {
    if (!glfwInit()) return NULL;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);

    GLFWmonitor *mon = fullscreen ? glfwGetPrimaryMonitor() : NULL;
    GLFWwindow *win = glfwCreateWindow(width, height, title, mon, NULL);
    if (!win) { glfwTerminate(); return NULL; }

    glfwMakeContextCurrent(win);
    glfwSwapInterval(vsync ? 1 : 0);

    if (load_gl_funcs() != 0) {
        glfwDestroyWindow(win);
        glfwTerminate();
        return NULL;
    }

    glViewport(0, 0, width, height);

    Engine *e = (Engine*)calloc(1, sizeof(Engine));
    if (!e) { glfwDestroyWindow(win); glfwTerminate(); return NULL; }

    e->win = win;
    e->w = width;
    e->h = height;
    e->open = true;
    e->pixel_art = pixel_art;
    e->last_time = glfwGetTime();
    e->delta = 0.016;
    e->target_fps = 60;

    glfwSetWindowUserPointer(win, e);
    glfwSetKeyCallback(win, key_cb);
    glfwSetMouseButtonCallback(win, mouse_cb);

    color_batch_init(&e->fill_batch, COLOR_VS, COLOR_FS);
    color_batch_init(&e->line_batch, COLOR_VS, COLOR_FS);
    tex_batch_init(&e->tex_batch, TEX_VS, TEX_FS);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(0, 0, 0, 1);

    return e;
}

void engine_close(Engine *e) {
    if (!e) return;
    e->open = false;
    if (e->font_ready) {
        glDeleteTextures(1, &e->font.tex_id);
        free(e->font.advance); free(e->font.xoff);
        free(e->font.yoff); free(e->font.glyph_w); free(e->font.glyph_h);
    }
    for (int i = 0; i < e->tex_count; i++) glDeleteTextures(1, &e->textures[i].tex_id);
    free(e->textures);

    glDeleteVertexArrays(1, &e->fill_batch.vao);
    glDeleteBuffers(1, &e->fill_batch.vbo);
    glDeleteProgram(e->fill_batch.shader);
    free(e->fill_batch.data);

    glDeleteVertexArrays(1, &e->line_batch.vao);
    glDeleteBuffers(1, &e->line_batch.vbo);
    glDeleteProgram(e->line_batch.shader);
    free(e->line_batch.data);

    glDeleteVertexArrays(1, &e->tex_batch.vao);
    glDeleteBuffers(1, &e->tex_batch.vbo);
    glDeleteProgram(e->tex_batch.shader);
    free(e->tex_batch.data);

    glfwDestroyWindow(e->win);
    glfwTerminate();
    free(e);
}

bool engine_is_open(Engine *e) { return e && e->open && !glfwWindowShouldClose(e->win); }

void engine_cls(Engine *e, Color c) {
    glClearColor(c.r/255.0f, c.g/255.0f, c.b/255.0f, c.a/255.0f);
    glClear(GL_COLOR_BUFFER_BIT);
}

void engine_swap_buffers(Engine *e) {
    tex_batch_flush(&e->tex_batch, e);
    color_batch_flush(&e->fill_batch, e);
    color_batch_flush(&e->line_batch, e);
    glfwSwapBuffers(e->win);
}

void engine_set_window_title(Engine *e, const char* title) { glfwSetWindowTitle(e->win, title); }
void engine_get_size(Engine *e, int* w, int* h) { if (w) *w = e->w; if (h) *h = e->h; }
double engine_get_ticks(Engine *e) { return glfwGetTime() * 1000.0; }
double engine_get_delta(Engine *e) { return e->delta; }
void engine_set_fps(Engine *e, int fps) { e->target_fps = fps; }
int engine_get_fps(Engine *e) { return e->target_fps; }

void engine_poll_events(Engine *e) {
    double now = glfwGetTime();
    e->delta = now - e->last_time;
    e->last_time = now;
    memcpy(e->prev_keys, e->keys, sizeof(e->keys));
    memcpy(e->prev_mouse, e->mouse_buttons, sizeof(e->mouse_buttons));
    e->prev_mouse_x = e->mouse_x;
    e->prev_mouse_y = e->mouse_y;
    glfwPollEvents();
    glfwGetCursorPos(e->win, &e->mouse_x, &e->mouse_y);
}

bool engine_key_down(Engine *e, int key) { return key >= 0 && key < 512 && e->keys[key]; }
bool engine_key_pressed(Engine *e, int key) { return key >= 0 && key < 512 && e->keys[key] && !e->prev_keys[key]; }
bool engine_key_released(Engine *e, int key) { return key >= 0 && key < 512 && !e->keys[key] && e->prev_keys[key]; }
bool engine_mouse_down(Engine *e, int btn) { return btn >= 0 && btn < 16 && e->mouse_buttons[btn]; }
bool engine_mouse_pressed(Engine *e, int btn) { return btn >= 0 && btn < 16 && e->mouse_buttons[btn] && !e->prev_mouse[btn]; }
bool engine_mouse_released(Engine *e, int btn) { return btn >= 0 && btn < 16 && !e->mouse_buttons[btn] && e->prev_mouse[btn]; }
void engine_mouse_pos(Engine *e, double* x, double* y) { if (x) *x = e->mouse_x; if (y) *y = e->mouse_y; }
void engine_mouse_delta(Engine *e, double* dx, double* dy) {
    if (dx) *dx = e->mouse_x - e->prev_mouse_x;
    if (dy) *dy = e->mouse_y - e->prev_mouse_y;
}

void engine_camera(Engine *e, float x, float y) {
    if (e->pixel_art) { e->cam_x = roundf(x); e->cam_y = roundf(y); }
    else { e->cam_x = x; e->cam_y = y; }
}

void engine_set_pixel_art(Engine *e, bool on) { e->pixel_art = on; }

/* ─── Drawing ─── */
void engine_rect(Engine *e, float x, float y, float w, float h, Color c) {
    float r = c.r/255.0f, g = c.g/255.0f, b = c.b/255.0f, a = c.a/255.0f, x2 = x+w, y2 = y+h;
    color_batch_add(&e->fill_batch, x, y, r, g, b, a);
    color_batch_add(&e->fill_batch, x2, y, r, g, b, a);
    color_batch_add(&e->fill_batch, x, y2, r, g, b, a);
    color_batch_add(&e->fill_batch, x2, y, r, g, b, a);
    color_batch_add(&e->fill_batch, x2, y2, r, g, b, a);
    color_batch_add(&e->fill_batch, x, y2, r, g, b, a);
}

void engine_rectb(Engine *e, float x, float y, float w, float h, Color c) {
    float r = c.r/255.0f, g = c.g/255.0f, b = c.b/255.0f, a = c.a/255.0f, x2 = x+w, y2 = y+h;
    color_batch_add(&e->line_batch, x, y, r, g, b, a);
    color_batch_add(&e->line_batch, x2, y, r, g, b, a);
    color_batch_add(&e->line_batch, x, y2, r, g, b, a);
    color_batch_add(&e->line_batch, x2, y2, r, g, b, a);
    color_batch_add(&e->line_batch, x, y, r, g, b, a);
    color_batch_add(&e->line_batch, x, y2, r, g, b, a);
    color_batch_add(&e->line_batch, x2, y, r, g, b, a);
    color_batch_add(&e->line_batch, x2, y2, r, g, b, a);
}

void engine_line(Engine *e, float x1, float y1, float x2, float y2, Color c) {
    float r = c.r/255.0f, g = c.g/255.0f, b = c.b/255.0f, a = c.a/255.0f;
    color_batch_add(&e->line_batch, x1, y1, r, g, b, a);
    color_batch_add(&e->line_batch, x2, y2, r, g, b, a);
}

void engine_circ(Engine *e, float cx, float cy, float r, Color c) {
    float rc = c.r/255.0f, gc = c.g/255.0f, bc = c.b/255.0f, ac = c.a/255.0f;
    int segs = (int)(r*2.0f+4); if (segs < 8) segs = 8; if (segs > 64) segs = 64;
    for (int i = 0; i < segs; i++) {
        float a1 = 2.0f*PI*i/segs, a2 = 2.0f*PI*(i+1)/segs;
        color_batch_add(&e->fill_batch, cx, cy, rc, gc, bc, ac);
        color_batch_add(&e->fill_batch, cx+r*cosf(a1), cy+r*sinf(a1), rc, gc, bc, ac);
        color_batch_add(&e->fill_batch, cx+r*cosf(a2), cy+r*sinf(a2), rc, gc, bc, ac);
    }
}

void engine_circb(Engine *e, float cx, float cy, float r, Color c) {
    float rc = c.r/255.0f, gc = c.g/255.0f, bc = c.b/255.0f, ac = c.a/255.0f;
    int segs = (int)(r*2.0f+4); if (segs < 8) segs = 8; if (segs > 64) segs = 64;
    for (int i = 0; i < segs; i++) {
        float a1 = 2.0f*PI*i/segs, a2 = 2.0f*PI*(i+1)/segs;
        color_batch_add(&e->line_batch, cx+r*cosf(a1), cy+r*sinf(a1), rc, gc, bc, ac);
        color_batch_add(&e->line_batch, cx+r*cosf(a2), cy+r*sinf(a2), rc, gc, bc, ac);
    }
}

void engine_tri(Engine *e, float x1, float y1, float x2, float y2, float x3, float y3, Color c) {
    float r = c.r/255.0f, g = c.g/255.0f, b = c.b/255.0f, a = c.a/255.0f;
    color_batch_add(&e->fill_batch, x1, y1, r, g, b, a);
    color_batch_add(&e->fill_batch, x2, y2, r, g, b, a);
    color_batch_add(&e->fill_batch, x3, y3, r, g, b, a);
}

/* ─── Text ─── */
static int font_lazy_init(Engine *e, int font_pt) {
    if (e->font_ready && e->font_pt == font_pt) return 0;
    if (e->font_ready) {
        glDeleteTextures(1, &e->font.tex_id);
        free(e->font.advance); free(e->font.xoff); free(e->font.yoff);
        free(e->font.glyph_w); free(e->font.glyph_h);
        e->font_ready = false;
    }
    const char *paths[] = {"../Engine/fonts/PressStart2P.ttf", "Engine/fonts/PressStart2P.ttf", "./PressStart2P.ttf", NULL};
    unsigned char *ttf = NULL;
    long sz = 0;
    for (int i = 0; paths[i]; i++) {
        FILE *fp = fopen(paths[i], "rb"); if (!fp) continue;
        fseek(fp, 0, SEEK_END); sz = ftell(fp); fseek(fp, 0, SEEK_SET);
        ttf = (unsigned char*)malloc(sz);
        if (!ttf || (long)fread(ttf, 1, sz, fp) != sz) { free(ttf); ttf = NULL; fclose(fp); continue; }
        fclose(fp); break;
    }
    if (!ttf) { fprintf(stderr, "Engine: font not found\n"); return -1; }
    int ret = font_atlas_init(&e->font, ttf, font_pt);
    free(ttf);
    if (ret == 0) { e->font_ready = true; e->font_pt = font_pt; }
    return ret;
}

void engine_text(Engine *e, const char* text, float x, float y, Color c, int font_size) {
    if (!text || !*text) return;
    if (font_size <= 0) font_size = e->font_pt;
    if (font_lazy_init(e, font_size) != 0) return;

    FontAtlas *fa = &e->font;
    float r = c.r/255.0f, g = c.g/255.0f, b = c.b/255.0f, a = c.a/255.0f;
    float cursor_x = x, base_y = y;
    float scale = (float)font_size / fa->cell_h;

    glUseProgram(e->tex_batch.shader);
    glUniform4f(e->tex_batch.tint_loc, r, g, b, a);
    if (e->tex_batch.active_tex != fa->tex_id && e->tex_batch.count > 0)
        tex_batch_flush(&e->tex_batch, e);
    e->tex_batch.active_tex = fa->tex_id;

    for (const char *p = text; *p; p++) {
        int ch = (unsigned char)*p;
        if (ch < 32 || ch > 126) continue;
        int idx = ch - 32, col = idx % fa->cols, row = idx / fa->cols;
        float gw = fa->glyph_w[idx] * scale, gh = fa->glyph_h[idx] * scale;
        float ox = fa->xoff[idx] * scale, oy = fa->yoff[idx] * scale;
        float tx = cursor_x + ox, ty = base_y + oy;
        float u0 = (float)(col*fa->cell_w+1)/fa->tex_w, v0 = (float)(row*fa->cell_h+1)/fa->tex_h;
        float u1 = (float)(col*fa->cell_w+1+fa->glyph_w[idx])/fa->tex_w;
        float v1 = (float)(row*fa->cell_h+1+fa->glyph_h[idx])/fa->tex_h;
        cursor_x += fa->advance[idx] * scale;
        tex_batch_add(&e->tex_batch, tx, ty, u0, v0);
        tex_batch_add(&e->tex_batch, tx+gw, ty, u1, v0);
        tex_batch_add(&e->tex_batch, tx, ty+gh, u0, v1);
        tex_batch_add(&e->tex_batch, tx+gw, ty, u1, v0);
        tex_batch_add(&e->tex_batch, tx+gw, ty+gh, u1, v1);
        tex_batch_add(&e->tex_batch, tx, ty+gh, u0, v1);
    }
}

void engine_text_center(Engine *e, const char* text, float x, float y, Color c, int font_size) {
    float w = engine_text_width(e, text, font_size);
    engine_text(e, text, x - w/2.0f, y, c, font_size);
}

float engine_text_width(Engine *e, const char* text, int font_size) {
    if (!text || !*text) return 0;
    if (font_size <= 0) font_size = e->font_pt;
    if (font_lazy_init(e, font_size) != 0) return 0;
    FontAtlas *fa = &e->font;
    float scale = (float)font_size / fa->cell_h, w = 0;
    for (const char *p = text; *p; p++) {
        int ch = (unsigned char)*p;
        if (ch >= 32 && ch <= 126) w += fa->advance[ch-32] * scale;
    }
    return w;
}

/* ─── Textures ─── */
Texture engine_texture_load(Engine *e, const char* path) {
    int w, h, n;
    unsigned char *data = stbi_load(path, &w, &h, &n, 4);
    if (!data) { fprintf(stderr, "Engine: tex load fail: %s\n", path); return 0; }
    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    stbi_image_free(data);
    if (e->tex_count >= e->tex_cap) {
        e->tex_cap = e->tex_cap ? e->tex_cap*2 : 16;
        e->textures = (TexInfo*)realloc(e->textures, e->tex_cap*sizeof(TexInfo));
    }
    int id = e->tex_count + 1;
    e->textures[e->tex_count].tex_id = tex;
    e->textures[e->tex_count].w = w;
    e->textures[e->tex_count].h = h;
    e->tex_count++;
    return id;
}

void engine_texture_free(Engine *e, Texture tex) {
    if (tex <= 0 || tex > e->tex_count) return;
    glDeleteTextures(1, &e->textures[tex-1].tex_id);
}

void engine_blit(Engine *e, Texture tex, float dx, float dy, float dw, float dh,
                 float sx, float sy, float sw, float sh, Color tint)
{
    if (tex <= 0 || tex > e->tex_count) return;
    GLuint gl_tex = e->textures[tex-1].tex_id;
    int tw = e->textures[tex-1].w, th = e->textures[tex-1].h;
    float u0 = sx/tw, v0 = sy/th, u1 = (sx+sw)/tw, v1 = (sy+sh)/th, x2 = dx+dw, y2 = dy+dh;
    glUseProgram(e->tex_batch.shader);
    glUniform4f(e->tex_batch.tint_loc, tint.r/255.0f, tint.g/255.0f, tint.b/255.0f, tint.a/255.0f);
    if (e->tex_batch.active_tex != gl_tex && e->tex_batch.count > 0)
        tex_batch_flush(&e->tex_batch, e);
    e->tex_batch.active_tex = gl_tex;
    tex_batch_add(&e->tex_batch, dx, dy, u0, v0);
    tex_batch_add(&e->tex_batch, x2, dy, u1, v0);
    tex_batch_add(&e->tex_batch, dx, y2, u0, v1);
    tex_batch_add(&e->tex_batch, x2, dy, u1, v0);
    tex_batch_add(&e->tex_batch, x2, y2, u1, v1);
    tex_batch_add(&e->tex_batch, dx, y2, u0, v1);
}

void engine_blit_full(Engine *e, Texture tex, float x, float y, Color tint) {
    if (tex <= 0 || tex > e->tex_count) return;
    int w = e->textures[tex-1].w, h = e->textures[tex-1].h;
    engine_blit(e, tex, x, y, (float)w, (float)h, 0, 0, (float)w, (float)h, tint);
}

/* ─── Run-loop ─── */
void engine_run(Engine* e, EngineUpdateFn update, EngineDrawFn draw) {
    double clock = glfwGetTime();
    double target_dt = 1.0 / e->target_fps;

    while (engine_is_open(e)) {
        double now = glfwGetTime();
        e->delta = now - clock;
        clock = now;

        engine_poll_events(e);

        if (engine_key_pressed(e, KEY_ESCAPE))
            break;

        update(e);
        draw(e);

        engine_swap_buffers(e);

        double elapsed = glfwGetTime() - now;
        double sleep = target_dt - elapsed;
        if (sleep > 0.002) {
            struct timespec ts;
            ts.tv_sec = (time_t)sleep;
            ts.tv_nsec = (long)((sleep - (time_t)sleep) * 1e9);
            nanosleep(&ts, NULL);
        }
    }
}

/* ─── Audio stubs ─── */
bool engine_audio_init(Engine *e, int ch) { (void)e; (void)ch; return false; }
void engine_audio_close(Engine *e) { (void)e; }
int engine_sound_load(Engine *e, const char* p) { (void)e; (void)p; return -1; }
void engine_sound_play(Engine *e, int s, int ch, float v, float sp) { (void)e; (void)s; (void)ch; (void)v; (void)sp; }
void engine_sound_stop_channel(Engine *e, int ch) { (void)e; (void)ch; }
void engine_music_load(Engine *e, const char* p) { (void)e; (void)p; }
void engine_music_play(Engine *e, float v) { (void)e; (void)v; }
void engine_music_stop(Engine *e) { (void)e; }
