#include <stdio.h>
#include <math.h>
#include "engine.h"

static float x = 100, y = 100, dx = 2, dy = 1.5f;
static float t = 0;

static void update(Engine *e) {
    t += (float)engine_get_delta(e);
    x += dx; y += dy;
    if (x <= 50 || x >= 590 - 40) dx = -dx;
    if (y <= 50 || y >= 430 - 40) dy = -dy;
}

static void draw(Engine *e) {
    engine_cls(e, RGB(20, 20, 30));
    engine_circ(e,20,20,50,RGB(0,0,0));
}

int main(void) {
    Engine *e = engine_init(640, 480, "C Engine Demo", 0, 1, 1);
    if (!e) return 1;
    engine_run(e, update, draw);
    engine_close(e);
    return 0;
}
